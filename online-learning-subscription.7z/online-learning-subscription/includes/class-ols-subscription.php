<?php
/**
 * Class OLS_Subscription
 * Handles the subscription logic for Online Learning product type.
 */
class OLS_Subscription {

    /**
     * Constructor.
     */
    public function __construct() {
        // Add hooks and filters
        add_action('woocommerce_product_options_general_product_data', array($this, 'ols_product_custom_fields'));
        add_action('woocommerce_process_product_meta', array($this, 'ols_save_product_custom_fields'));
        add_filter('woocommerce_product_data_tabs', array($this, 'ols_custom_product_tabs'));
        add_action('woocommerce_product_data_panels', array($this, 'ols_custom_product_panels'));
        add_action('woocommerce_process_product_meta', array($this, 'ols_save_custom_product_tabs'));
        add_filter('woocommerce_subscription_price_string', array($this, 'ols_custom_subscription_price_string'), 10, 3);
        add_action('woocommerce_single_product_summary', array($this, 'ols_display_subscription_details'), 20);
    }

    /**
     * Initialize the subscription logic.
     */
    public function init() {
        // Initialize any necessary functionalities
    }

    /**
     * Add custom fields to product general settings.
     */
    public function ols_product_custom_fields() {
        global $post;

        echo '<div class="options_group">';

        // Subscription Fee
        woocommerce_wp_text_input(array(
            'id'          => '_subscription_fee',
            'label'       => __('Subscription Fee', 'online-learning-subscription'),
            'placeholder' => '',
            'description' => __('Enter the monthly subscription fee for the Online Learning product.', 'online-learning-subscription'),
            'type'        => 'number',
            'custom_attributes' => array(
                'step'  => 'any',
                'min'   => '0'
            )
        ));

        // Hourly Rate
        woocommerce_wp_text_input(array(
            'id'          => '_hourly_rate',
            'label'       => __('Hourly Rate', 'online-learning-subscription'),
            'placeholder' => '',
            'description' => __('Enter the hourly rate for additional usage beyond the subscription.', 'online-learning-subscription'),
            'type'        => 'number',
            'custom_attributes' => array(
                'step'  => 'any',
                'min'   => '0'
            )
        ));

        echo '</div>';
    }

    /**
     * Save custom fields data when product is saved.
     *
     * @param int $post_id Product ID.
     */
    public function ols_save_product_custom_fields($post_id) {
        $subscription_fee = isset($_POST['_subscription_fee']) ? wc_clean(wp_unslash($_POST['_subscription_fee'])) : '';
        $hourly_rate = isset($_POST['_hourly_rate']) ? wc_clean(wp_unslash($_POST['_hourly_rate'])) : '';

        update_post_meta($post_id, '_subscription_fee', $subscription_fee);
        update_post_meta($post_id, '_hourly_rate', $hourly_rate);
    }

    /**
     * Add custom tabs to product data meta box.
     *
     * @param array $tabs Product tabs.
     * @return array Updated product tabs.
     */
    public function ols_custom_product_tabs($tabs) {
        $tabs['subscription'] = array(
            'label'    => __('Subscription', 'online-learning-subscription'),
            'target'   => 'subscription_options',
            'class'    => array(),
            'priority' => 25,
        );
        return $tabs;
    }

    /**
     * Custom product panels for subscription tab.
     */
    public function ols_custom_product_panels() {
        global $post;

        echo '<div id="subscription_options" class="panel woocommerce_options_panel">';
        echo '<div class="options_group">';

        // Subscription Fee
        woocommerce_wp_text_input(array(
            'id'          => '_subscription_fee',
            'label'       => __('Subscription Fee', 'online-learning-subscription'),
            'placeholder' => '',
            'description' => __('Enter the monthly subscription fee for the Online Learning product.', 'online-learning-subscription'),
            'type'        => 'number',
            'custom_attributes' => array(
                'step'  => 'any',
                'min'   => '0'
            )
        ));

        // Hourly Rate
        woocommerce_wp_text_input(array(
            'id'          => '_hourly_rate',
            'label'       => __('Hourly Rate', 'online-learning-subscription'),
            'placeholder' => '',
            'description' => __('Enter the hourly rate for additional usage beyond the subscription.', 'online-learning-subscription'),
            'type'        => 'number',
            'custom_attributes' => array(
                'step'  => 'any',
                'min'   => '0'
            )
        ));

        echo '</div>';
        echo '</div>';
    }

    /**
     * Save custom product tabs data when product is saved.
     *
     * @param int $post_id Product ID.
     */
    public function ols_save_custom_product_tabs($post_id) {
        $subscription_fee = isset($_POST['_subscription_fee']) ? wc_clean(wp_unslash($_POST['_subscription_fee'])) : '';
        $hourly_rate = isset($_POST['_hourly_rate']) ? wc_clean(wp_unslash($_POST['_hourly_rate'])) : '';

        update_post_meta($post_id, '_subscription_fee', $subscription_fee);
        update_post_meta($post_id, '_hourly_rate', $hourly_rate);
    }

    /**
     * Customize subscription price string displayed in WooCommerce.
     *
     * @param string $subscription_string Default subscription price string.
     * @param object $subscription WooCommerce Subscription object.
     * @param bool $include_tax Whether to include taxes.
     * @return string Customized subscription price string.
     */
    public function ols_custom_subscription_price_string($subscription_string, $subscription, $include_tax) {
        $subscription_fee = get_post_meta($subscription->get_parent_id(), '_subscription_fee', true);
        $hourly_rate = get_post_meta($subscription->get_parent_id(), '_hourly_rate', true);

        if ($subscription_fee && $hourly_rate) {
            $subscription_string = sprintf(__('Subscription Fee: %s / month + $%s / hr', 'online-learning-subscription'), wc_price($subscription_fee), $hourly_rate);
        }

        return $subscription_string;
    }

    /**
     * Display subscription details on the single product page.
     */
    public function ols_display_subscription_details() {
        global $product;

        if ($product->get_type() === 'online_learning') {
            $subscription_fee = get_post_meta($product->get_id(), '_subscription_fee', true);
            $hourly_rate = get_post_meta($product->get_id(), '_hourly_rate', true);

            if ($subscription_fee && $hourly_rate) {
                echo '<div class="ols-subscription-details">';
                echo '<h2>' . __('Subscription Details', 'online-learning-subscription') . '</h2>';
                echo '<p>' . sprintf(__('Subscription Fee: %s per month', 'online-learning-subscription'), wc_price($subscription_fee)) . '</p>';
                echo '<p>' . sprintf(__('Hourly Rate for additional usage: %s per hour', 'online-learning-subscription'), wc_price($hourly_rate)) . '</p>';
                echo '</div>';
            }
        }
    }
}

new OLS_Subscription();
