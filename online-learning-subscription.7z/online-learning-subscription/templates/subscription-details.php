<?php
/**
 * Template for displaying subscription details in WooCommerce user account.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/subscription-details.php.
 *
 * @package Online_Learning_Subscription
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Ensure user is logged in
if (!is_user_logged_in()) {
    return;
}

$user_id = get_current_user_id();

// Get user's active subscriptions
$active_subscriptions = wcs_get_users_subscriptions($user_id, array(
    'subscriptions_per_page' => -1,
    'status' => array('active', 'pending', 'on-hold'),
));

if (empty($active_subscriptions)) {
    echo '<p>' . __('You do not have any active subscriptions.', 'online-learning-subscription') . '</p>';
    return;
}

?>

<div class="subscription-details">

    <h2><?php esc_html_e('Active Subscriptions', 'online-learning-subscription'); ?></h2>

    <ul class="subscriptions-list">
        <?php foreach ($active_subscriptions as $subscription) : ?>
            <li class="subscription-item">
                <span class="subscription-name"><?php echo esc_html($subscription->get_product()->get_name()); ?></span>
                <span class="subscription-status"><?php echo esc_html(wc_get_order_status_name($subscription->get_status())); ?></span>
                <span class="subscription-next-payment"><?php echo esc_html($subscription->get_date('next_payment')); ?></span>
                <span class="subscription-price"><?php echo esc_html($subscription->get_formatted_order_total()); ?></span>
            </li>
        <?php endforeach; ?>
    </ul>

</div>
