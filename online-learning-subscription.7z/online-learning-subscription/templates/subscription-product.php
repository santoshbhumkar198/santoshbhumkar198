<?php
/**
 * Template for displaying the subscription product in WooCommerce.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/subscription-product.php.
 *
 * @package Online_Learning_Subscription
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

global $product;

// Ensure the product is set up as a subscription product
if (!$product || $product->get_type() !== 'online_learning') {
    return;
}

// Get subscription fee and hourly rate
$subscription_fee = get_post_meta($product->get_id(), '_subscription_fee', true);
$hourly_rate = get_post_meta($product->get_id(), '_hourly_rate', true);

?>

<div class="subscription-product">

    <form class="cart" method="post" enctype='multipart/form-data'>
        <div class="subscription-options">
            <h2><?php echo esc_html($product->get_name()); ?></h2>

            <p class="price"><?php echo wc_price($subscription_fee) . ' / month'; ?></p>
            <p class="price"><?php echo sprintf(__('Hourly Rate: %s / hour', 'online-learning-subscription'), wc_price($hourly_rate)); ?></p>

            <p class="description"><?php echo esc_html($product->get_description()); ?></p>

            <label for="subscription_duration"><?php esc_html_e('Subscription Duration:', 'online-learning-subscription'); ?></label>
            <select name="subscription_duration" id="subscription_duration">
                <option value="1"><?php esc_html_e('1 month', 'online-learning-subscription'); ?></option>
                <option value="3"><?php esc_html_e('3 months', 'online-learning-subscription'); ?></option>
                <option value="6"><?php esc_html_e('6 months', 'online-learning-subscription'); ?></option>
                <option value="12"><?php esc_html_e('12 months', 'online-learning-subscription'); ?></option>
            </select>

            <label for="additional_hours"><?php esc_html_e('Additional Hours (if any):', 'online-learning-subscription'); ?></label>
            <input type="number" name="additional_hours" id="additional_hours" value="0" min="0" step="1" />

            <?php
            // Ensure the product is purchasable
            if ($product->is_purchasable()) : ?>
                <button type="submit" class="single_add_to_cart_button button alt"><?php echo esc_html($product->single_add_to_cart_text()); ?></button>
            <?php endif; ?>
        </div>
    </form>

</div>

<style>
.subscription-product {
    border: 1px solid #e5e5e5;
    padding: 20px;
    margin: 20px 0;
    border-radius: 5px;
}

.subscription-product .subscription-options {
    max-width: 600px;
    margin: 0 auto;
    text-align: center;
}

.subscription-product h2 {
    font-size: 24px;
    margin-bottom: 10px;
}

.subscription-product .price {
    font-size: 18px;
    margin: 10px 0;
    color: #555;
}

.subscription-product .description {
    font-size: 14px;
    margin-bottom: 20px;
    color: #777;
}

.subscription-product label {
    display: block;
    font-size: 14px;
    margin-bottom: 5px;
    color: #333;
}

.subscription-product select,
.subscription-product input[type="number"] {
    width: 100%;
    padding: 8px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 3px;
    box-sizing: border-box;
}

.subscription-product button {
    display: inline-block;
    padding: 10px 20px;
    background-color: #0073aa;
    color: #fff;
    text-transform: uppercase;
    border: none;
    border-radius: 3px;
    cursor: pointer;
    font-size: 16px;
}

.subscription-product button:hover {
    background-color: #005f8d;
}
</style>
