<?php
/**
 * Plugin Name: Online Learning Subscription
 * Description: Subscription-based online learning application for WooCommerce.
 * Version: 1.0.0
 * Author: Santosh Bhumkar
 * Author URI: Your Site URL
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Include necessary files
 */
require_once plugin_dir_path(__FILE__) . 'includes/class-ols-subscription.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-ols-cron-handler.php';

/**
 * Plugin activation and deactivation hooks
 */
register_activation_hook(__FILE__, 'ols_plugin_activate');
register_deactivation_hook(__FILE__, 'ols_plugin_deactivate');

function ols_plugin_activate() {
    // Activation code, if needed
}

function ols_plugin_deactivate() {
    // Deactivation code, if needed
}

/**
 * Initialize the subscription plugin
 */
function ols_init_subscription_plugin() {
    if (class_exists('OLS_Subscription')) {
        $ols_subscription = new OLS_Subscription();
        $ols_subscription->init();
    }
}
add_action('plugins_loaded', 'ols_init_subscription_plugin');

/**
 * Register custom WooCommerce product type
 */
function ols_register_subscription_product_type($product_types) {
    $product_types['online_learning'] = __('Online Learning', 'online-learning-subscription');
    return $product_types;
}
add_filter('product_type_selector', 'ols_register_subscription_product_type');

/**
 * Load text domain for translation
 */
function ols_load_textdomain() {
    load_plugin_textdomain('online-learning-subscription', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'ols_load_textdomain');

/**
 * Enqueue plugin styles
 */
function ols_enqueue_styles() {
    wp_enqueue_style('ols-styles', plugin_dir_url(__FILE__) . 'assets/css/styles.css');
}
add_action('wp_enqueue_scripts', 'ols_enqueue_styles');

/**
 * Register the shortcodes
 */
function ols_register_shortcodes() {
    add_shortcode('ols_account_links', 'ols_account_links_shortcode');
    add_shortcode('ol_subscription_form', 'ol_subscription_form_shortcode');
    add_shortcode('ol_admin_page', 'ol_admin_page_shortcode');
}
add_action('init', 'ols_register_shortcodes');

/**
 * Shortcode function to display account links
 */
function ols_account_links_shortcode() {
    ob_start();
    ?>
    <div class="ols-account-links">
        <a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id'))); ?>"><?php esc_html_e('My Account', 'online-learning-subscription'); ?></a>
        <a href="<?php echo esc_url(wc_get_endpoint_url('subscriptions', '', get_permalink(get_option('woocommerce_myaccount_page_id')))); ?>"><?php esc_html_e('My Subscriptions', 'online-learning-subscription'); ?></a>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Shortcode function to display subscription form
 */
function ol_subscription_form_shortcode() {
    ob_start();
    ?>
    <form class="ol-subscription-form" method="post" action="">
        <label for="subscription_duration"><?php esc_html_e('Subscription Duration:', 'online-learning-subscription'); ?></label>
        <select name="subscription_duration" id="subscription_duration">
            <option value="1"><?php esc_html_e('1 month', 'online-learning-subscription'); ?></option>
            <option value="3"><?php esc_html_e('3 months', 'online-learning-subscription'); ?></option>
            <option value="6"><?php esc_html_e('6 months', 'online-learning-subscription'); ?></option>
            <option value="12"><?php esc_html_e('12 months', 'online-learning-subscription'); ?></option>
        </select>

        <label for="additional_hours"><?php esc_html_e('Additional Hours (if any):', 'online-learning-subscription'); ?></label>
        <input type="number" name="additional_hours" id="additional_hours" value="0" min="0" step="1" />

        <button type="submit" class="button alt"><?php esc_html_e('Subscribe', 'online-learning-subscription'); ?></button>
    </form>
    <?php
    return ob_get_clean();
}

/**
 * Shortcode function to display admin page content
 */
function ol_admin_page_shortcode() {
    if (!current_user_can('manage_options')) {
        return '<p>' . esc_html__('You do not have sufficient permissions to access this page.', 'online-learning-subscription') . '</p>';
    }

    // Fetch subscriptions data
    $subscriptions = wc_get_orders(array(
        'limit' => -1,
        'type' => 'shop_subscription',
        'status' => array('active', 'on-hold', 'pending', 'completed')
    ));

    ob_start();
    ?>
    <div class="ol-admin-page">
        <h2><?php esc_html_e('Online Learning Subscription Admin Page', 'online-learning-subscription'); ?></h2>
        <p><?php esc_html_e('Manage your online learning subscriptions here.', 'online-learning-subscription'); ?></p>
        
        <table class="widefat fixed" cellspacing="0">
            <thead>
                <tr>
                    <th><?php esc_html_e('Subscription ID', 'online-learning-subscription'); ?></th>
                    <th><?php esc_html_e('Customer', 'online-learning-subscription'); ?></th>
                    <th><?php esc_html_e('Status', 'online-learning-subscription'); ?></th>
                    <th><?php esc_html_e('Start Date', 'online-learning-subscription'); ?></th>
                    <th><?php esc_html_e('End Date', 'online-learning-subscription'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($subscriptions)) {
                    foreach ($subscriptions as $subscription) {
                        $subscription_id = $subscription->get_id();
                        $customer = $subscription->get_billing_first_name() . ' ' . $subscription->get_billing_last_name();
                        $status = wc_get_order_status_name($subscription->get_status());
                        $start_date = $subscription->get_date_created()->date('Y-m-d');
                        $end_date = $subscription->get_date_completed() ? $subscription->get_date_completed()->date('Y-m-d') : __('N/A', 'online-learning-subscription');
                        ?>
                        <tr>
                            <td><?php echo esc_html($subscription_id); ?></td>
                            <td><?php echo esc_html($customer); ?></td>
                            <td><?php echo esc_html($status); ?></td>
                            <td><?php echo esc_html($start_date); ?></td>
                            <td><?php echo esc_html($end_date); ?></td>
                        </tr>
                        <?php
                    }
                } else {
                    ?>
                    <tr>
                        <td colspan="5"><?php esc_html_e('No subscriptions found.', 'online-learning-subscription'); ?></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
    return ob_get_clean();
}
